import { useEffect, useState } from 'react';

function App() {
  const [count, setCount] = useState(0);
  const [message, setMessage] = useState('');
  const [data, setData] = useState([]);

  const handleIncrease = () => {
    const newCount = count + 1;
    setCount(newCount);
    if (newCount >= 10) setMessage("You've reached the limit!");
    else setMessage('');
  };

  const handleDecrease = () => {
    const newCount = count > 0 ? count - 1 : 0;
    setCount(newCount);
    if (newCount < 10) setMessage('');
  };

  useEffect(() => {
    fetch('http://localhost:3001/items')
      .then(res => res.json())
      .then(data => setData(data))
      .catch(err => console.error("Fetch error:", err));
  }, []);

  return (
    <main style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Click Counter</h1>
      <h2>Count: {count}</h2>
      <button onClick={handleIncrease}>Increase</button>
      <button onClick={handleDecrease} style={{ marginLeft: '10px' }}>Decrease</button>
      {message && <p style={{ color: 'red' }}>{message}</p>}
      <h3>Fetched Items:</h3>
      <ul>
        {data.map(item => <li key={item.id}>{item.name}</li>)}
      </ul>
    </main>
  );
}

export default App;